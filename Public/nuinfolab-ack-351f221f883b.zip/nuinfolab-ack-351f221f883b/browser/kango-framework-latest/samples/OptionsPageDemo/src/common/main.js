﻿kango.ui.browserButton.addEventListener(kango.ui.browserButton.event.COMMAND, function() {
    kango.ui.optionsPage.open();
});