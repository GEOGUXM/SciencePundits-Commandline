kango.Internationalization.prototype.getApplicationLocale=function(){return window.navigator.language||null};
