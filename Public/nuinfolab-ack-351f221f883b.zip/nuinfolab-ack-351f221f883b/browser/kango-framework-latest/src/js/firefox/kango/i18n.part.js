kango.Internationalization.prototype.getApplicationLocale=function(){return Services.locale.getApplicationLocale().getCategory("NSILOCALE_MESSAGES")};
