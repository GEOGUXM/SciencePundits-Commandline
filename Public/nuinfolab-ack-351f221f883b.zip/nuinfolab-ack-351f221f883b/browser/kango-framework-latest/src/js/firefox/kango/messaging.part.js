kango.MessageRouter=function(){this.superclass.apply(this,arguments)};kango.MessageRouter.prototype=kango.oop.extend(kango.MessageRouterBase,{});
